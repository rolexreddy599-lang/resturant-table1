# TableMate — Restaurant Table Reservation Management System

**Mini Project Founder:** Purushotham Reddy  
**Technology:** HTML5, CSS3, JavaScript, Browser LocalStorage

## Features
- Responsive restaurant landing page and reservation form
- Guest details, date, time, number of guests and seating preference
- Client-side form validation and past-date prevention
- Reservation dashboard with Pending, Confirmed, Completed and Cancelled states
- Search reservations by guest, phone, email or date
- Filter reservations by status
- Dashboard statistics and CSV export
- Browser LocalStorage persistence

## Run the project
1. Extract `restaurant_table_reservation.zip`.
2. Open the `restaurant_table_reservation` folder in VS Code.
3. Open `index.html` in a browser, or use the VS Code Live Server extension.
4. Submit a reservation and scroll to the Reservation Dashboard to manage it.

## Project structure
```text
restaurant_table_reservation/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── app.js
└── README.md
```

## Important project limitation
This is a front-end academic mini project. Data is stored only in the current browser using LocalStorage. It is not shared between devices and has no real user authentication, payment processing, server, or database. For a real restaurant deployment, connect a backend (for example Java/Spring Boot or PHP) and MySQL, add secure staff login, and validate bookings on the server.

## Suggested modules for project explanation
1. Customer reservation module
2. Reservation validation module
3. Staff reservation management module
4. Search and status filter module
5. Reports / CSV export module
