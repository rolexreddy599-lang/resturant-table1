const STORAGE_KEY = "tablemate_reservations_v1";
const $ = (id) => document.getElementById(id);
let reservations = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");

const today = new Date();
const localDate = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
$("date").min = localDate;
$("year").textContent = new Date().getFullYear();

function save() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(reservations));
  render();
}
function notify(message) {
  const toast = $("toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(notify.timer);
  notify.timer = setTimeout(() => toast.classList.remove("show"), 2800);
}
function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function render() {
  const query = $("searchInput").value.trim().toLowerCase();
  const filter = $("statusFilter").value;
  const filtered = reservations.filter(r => {
    const matches = [r.name, r.phone, r.date, r.email].join(" ").toLowerCase().includes(query);
    return matches && (filter === "All" || r.status === filter);
  });
  $("totalCount").textContent = reservations.length;
  $("pendingCount").textContent = reservations.filter(r => r.status === "Pending").length;
  $("confirmedCount").textContent = reservations.filter(r => r.status === "Confirmed").length;
  $("guestCount").textContent = reservations.filter(r => !["Cancelled"].includes(r.status)).reduce((sum, r) => sum + Number(r.guests), 0);
  const tbody = $("reservationRows");
  if (!filtered.length) {
    tbody.innerHTML = `<tr><td colspan="6" class="empty">${reservations.length ? "No matching reservations." : "No reservations yet. Add your first booking above."}</td></tr>`;
    return;
  }
  tbody.innerHTML = filtered.sort((a,b) => (a.date + a.time).localeCompare(b.date + b.time)).map(r => `
    <tr>
      <td class="guest-cell"><strong>${escapeHTML(r.name)}</strong><small>${escapeHTML(r.phone)}</small></td>
      <td>${escapeHTML(r.date)}<br>${escapeHTML(r.time)}</td>
      <td>${escapeHTML(r.guests)}</td><td>${escapeHTML(r.seating)}</td>
      <td><span class="status ${escapeHTML(r.status)}">${escapeHTML(r.status)}</span></td>
      <td><div class="action-group">
        ${r.status === "Pending" ? `<button class="action-btn" data-action="Confirmed" data-id="${r.id}">Confirm</button>` : ""}
        ${r.status === "Confirmed" ? `<button class="action-btn" data-action="Completed" data-id="${r.id}">Complete</button>` : ""}
        ${!["Cancelled","Completed"].includes(r.status) ? `<button class="action-btn" data-action="Cancelled" data-id="${r.id}">Cancel</button>` : ""}
        <button class="action-btn" data-action="Delete" data-id="${r.id}">Delete</button>
      </div></td>
    </tr>`).join("");
}
$("reservationForm").addEventListener("submit", event => {
  event.preventDefault();
  const date = $("date").value;
  if (date < localDate) return notify("Please choose today or a future date.");
  const reservation = {
    id: (crypto.randomUUID ? crypto.randomUUID() : String(Date.now())),
    name: $("guestName").value.trim(),
    phone: $("phone").value.trim(),
    email: $("email").value.trim(),
    guests: $("guests").value,
    date, time: $("time").value,
    seating: $("seating").value,
    notes: $("notes").value.trim(),
    status: "Pending",
    createdAt: new Date().toISOString()
  };
  if (!reservation.name || !reservation.phone || !reservation.email || !reservation.guests || !reservation.time) {
    return notify("Please complete all required fields.");
  }
  reservations.push(reservation);
  save();
  event.target.reset();
  $("date").min = localDate;
  notify("Reservation saved! Your booking is pending confirmation.");
  $("dashboard").scrollIntoView({behavior:"smooth"});
});
$("reservationRows").addEventListener("click", event => {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  const {action, id} = button.dataset;
  if (action === "Delete") {
    if (!confirm("Delete this reservation permanently?")) return;
    reservations = reservations.filter(r => r.id !== id);
  } else {
    const item = reservations.find(r => r.id === id);
    if (item) item.status = action;
  }
  save();
  notify(action === "Delete" ? "Reservation deleted." : `Reservation marked ${action.toLowerCase()}.`);
});
$("searchInput").addEventListener("input", render);
$("statusFilter").addEventListener("change", render);
$("exportBtn").addEventListener("click", () => {
  if (!reservations.length) return notify("There are no reservations to export.");
  const headers = ["Name","Phone","Email","Guests","Date","Time","Seating","Notes","Status"];
  const rows = reservations.map(r => [r.name,r.phone,r.email,r.guests,r.date,r.time,r.seating,r.notes,r.status]);
  const csv = [headers,...rows].map(row => row.map(value => `"${String(value ?? "").replace(/"/g,'""')}"`).join(",")).join("\n");
  const blob = new Blob([csv], {type:"text/csv;charset=utf-8;"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a"); a.href = url; a.download = "tablemate-reservations.csv"; a.click();
  URL.revokeObjectURL(url);
  notify("CSV export downloaded.");
});
render();
